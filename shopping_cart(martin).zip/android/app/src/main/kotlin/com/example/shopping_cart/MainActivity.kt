package com.example.shopping_cart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
